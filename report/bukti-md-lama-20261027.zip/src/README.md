# `src/` — Rencana Modul (kode ditulis tim, tidak ada implementasi di sini)

Struktur ini dibuat supaya tiga perangkat cukup copy satu folder proyek yang sama, tapi tiap
perangkat hanya menjalankan entry point miliknya (`deploy/README.md`).

## Entry point (satu per perangkat)

| File | Jalan di | Peran |
|------|----------|-------|
| `kdc/main.py` | Perangkat 1 (`IP_KDC`) | Listener port KDC, simpan master key, bangkitkan & distribusikan session key |
| `alice/main.py` | Perangkat 2 | Hubungi KDC (langkah 1–2), kirim tiket ke Bob (3), chat dua arah (6) + menu interaktif |
| `bob/main.py` | Perangkat 3 | Listener chat, buka tiket (langkah 3), jawab challenge (4), chat dua arah + menu interaktif |

## `ksilib/` — dipakai bertiga (jangan diduplikasi)

| Modul | Isi yang diharapkan | Ketentuan |
|-------|--------------------|-----------|
| `ksilib/aes/sbox.py` | Tabel S-Box & inverse S-Box | no.4 manual |
| `ksilib/aes/keyexp.py` | Key expansion: 16-byte key → round key, RotWord/SubWord/Rcon | no.4 |
| `ksilib/aes/rounds.py` | SubBytes, ShiftRows, MixColumns, AddRoundKey + versi inverse, aritmetika GF(2^8) (`xtime`) | no.4 |
| `ksilib/aes/core.py` | `encrypt_block`, `decrypt_block`, mode ECB/CBC, padding PKCS#7 | no.4 |
| `ksilib/kdc/messages.py` | Susun/parsing pesan `LANGKAH1..5`, encoding tiket `{K_ab,A}_K_bs` | no.2 |
| `ksilib/kdc/server_logic.py` | Alur KDC: cocokkan nama, bangkitkan `K_ab`, enkripsi dengan `K_as`/`K_bs` | no.2 |
| `ksilib/kdc/keystore.py` | Muat master key & session key dari config, ganti key runtime | no.4, no.5 |
| `ksilib/net/framing.py` | `send_msg`/`recv_msg` dengan header panjang (TCP stream, no.4 ASCII+hex) | no.3 |
| `ksilib/net/endpoint.py` | Listener (thread) + penghubung keluar, supaya kedua sisi bisa sender & receiver | no.3 |
| `ksilib/utils/asciihex.py` | ASCII↔bytes, bytes↔heks, validasi ASCII (tolak non-ASCII) | no.4 |
| `ksilib/utils/cli.py` | Loop menu interaktif: `/key`, `/kirim`, `/terima`, `/test`, `/quit` | no.5 |
| `ksilib/utils/log.py` | Log ber-stamp `[waktu][peran]`, format plaintext vs ciphertext | no.6, laporan |

## Larangan import (cek sebelum demo)

```bash
grep -RinE "import (Crypto|cryptography)|from (Crypto|cryptography)|pycryptodome|Fernet" src/ && echo "GAGAL: harus manual" || echo "OK: tidak pakai library crypto"
```

Boleh: `socket`, `threading`, `selectors`, `struct`, `os`, `sys`, `json`, `secrets`/`random`
(untuk membangkitkan session key), `argparse`, `time`, `binascii`.
Tidak boleh: library yang sudah menyediakan AES/kripto siap pakai — itu melanggar "HARUS MANUAL".

## Gaya kode

- Fungsi kecil sesuai nama transformasi AES (`sub_bytes(state)` dsb) supaya bisa ditunjuk saat demo.
- Key tidak pernah ditulis literal di `.py`; hanya dari config/env atau input.
- Setiap modul ada docstring satu baris + catatan referensi (mis. "S-Box: FIPS-197 §5.1.1") —
  ini membantu no.11 (sumber jelas) dan no.7 (paham).
