# `demo/` — Persiapan Tampil

- `not-poin/` — **hanya poin-poin** (bukan kalimat penuh). Syarat no.7 melarang baca plek ketiplek,
  jadi naskah utuh sengaja tidak dibuat. Kalau ada naskah lengkap, kemungkinan besar akan terbaca.
- `screenshots/` — tangkapan layar Wireshark, log 5 langkah, hasil ganti key.
- Isikan test case live ke `docs/04` tabelnya saat demo berlangsung, lalu simpan ke
  `report/bab-4-hasil/`.

## Yang dibawa

- [ ] 3 perangkat/VM siap + charger/adaptor.
- [ ] Laptop pengamat dengan Wireshark (interface & filter sudah aktif).
- [ ] Folder `.zip` cadangan proyek + salinan di perangkat kedua.
- [ ] Kabel/LAN kalau lab tidak stabil lewat Wi‑Fi.
- [ ] `docs/06-checklist-demo.md` sudah dicentang semua H-1.
- [ ] Print/kartu kecil berisi: IP 3 perangkat, port, dan daftar filter Wireshark.
