# Not Poin Demo (BUKAN naskah baca)

Format sengaja bullet pendek. Satu bullet = satu kalimat yang muncul dari kepala, bukan dibaca.
Nama di kurung siku = siapa yang megang bagian itu (isi dari `docs/07-pembagian-tim.md`).

## 1. Pembuka (1 mnt) [nama 1]

- Judul: distribusi session key pakai KDC + AES manual, 3 perangkat.
- Angka kunci: 3 IP, 5 langkah distribusi, AES-128 tanpa library.
- Pembagian: siapa pegang apa.

## 2. Arsitektur (2 mnt) [nama 1]

- Peran KDC / Alice / Bob, tabel IP & port.
- Kenapa client-client: dua-duanya bisa kirim & terima.
- Master key: `K_as` cuma Alice+KDC, `K_bs` cuma Bob+KDC, `K_ab` tidak pernah terbuk di kabel.

## 3. Skenario langkah 1–5 (4 mnt) [nama 3]

- 1: Alice minta izin ke KDC (`A, B`).
- 2: KDC balas `{K_ab, B, {K_ab,A}_K_bs}_K_as` — tunjuk heks-nya.
- 3: Alice forward tiket ke Bob — Alice tidak bisa baca tiketnya.
- 4: Bob kirim `{N_b}_K_ab` — bukti dia punya kunci.
- 5: Alice balas → kedua sisi pegang `K_ab` sama.
- Cocokan dengan slide kelas: sebut nomor slide.

## 4. Bukti AES manual (3 mnt) [nama 2]

- Empat transformasi + urutan round, tanpa MixColumns di round terakhir.
- Key expansion + Rcon, key ASCII 16 char.
- Known-answer FIPS-197: `69c4e0d8...` cocok → benar.
- ASCII masuk, heks keluar (tunjuk dua kolom berdampingan).

## 5. Chat dua arah + interaktif (3 mnt) [nama 4]

- Alice → Bob 1 pesan, Bob → Alice 1 pesan (tanpa restart).
- `/key` ganti key di tengah jalan → ciphertext berubah.
- Key dari `.env`/input, tidak ada literal di kode (`grep` cepat kalau diminta).

## 6. Wireshark (3 mnt) [nama 4]

- Interface + filter yang dipakai (sebut IP-nya).
- Lihat langkah 1–2 dan 6 di stream yang sama.
- Yang terlihat vs yang tidak terlihat.
- (kalau diambil) bandingkan mode `PLAINTEKS-TEST`.

## 7. Penutup (1 mnt) [nama 1]

- Kesimpulan: key disamakan lewat jalur terenkripsi master key, lalu dipakai AES.
- Fitur tambahan + trade-off-nya.
- Yang belum: mis. forward secrecy, ganti kunci berkala.

## Antisipasi pertanyaan

| Ditanya | Jawab inti | Orang |
|---------|-----------|-------|
| Kenapa KDC perlu? | Dua pihak tak punya kunci bersama; KDC jadi pihak tepercaya | 3 |
| Kenapa tiket `{K_ab,A}_K_bs`? | Cuma Bob yang bisa buka → Alice tak perlu tahu `K_bs` | 3 |
| Kenapa AES-128 ECB? | Sederhana & cukup untuk menunjukkan alur; ECB punya kelemahan pola → jelaskan | 2 |
| Kalau `K_as` bocor? | Penyadap dapat semua session key Alice → sebabnya butuh rotasi/asimetri | 3 |
| Di mana key dibaca? | `config/hosts/*.env` lewat `keystore.py`, override via menu | 4 |
| Kenapa heks? | Agar ciphertext aman lewat kanal teks ASCII & terbaca manusia | 2 |
| Apa bedanya sama library? | S-Box, round, key expansion, GF(2^8) ditulis sendiri | 2 |
