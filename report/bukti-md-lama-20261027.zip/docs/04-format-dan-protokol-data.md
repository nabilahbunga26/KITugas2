# Format Data & Protokol di Kabel (syarat no.4)

## Aturan format

| Data | Format | Contoh | Cara di kode |
|------|--------|--------|--------------|
| Key (master & session) | **ASCII**, 16 karakter (AES-128) | `S3ssionKeyAliceB` | `key.encode("ascii")` -> `bytes` 16 |
| Plaintext | **ASCII** | `halo bob` | `s.encode("ascii")` |
| Ciphertext | **HEKS** (hex string, tampil & dikirim) | `3a7f19c0...` | `ciphertext.hex()` / `bytes.fromhex()` |

- Pakai ASCII murni, bukan UTF-8: karakter di luar 0–127 ditolak dengan pesan yang jelas
  ("plaintext harus ASCII"), jangan diam-diam salah hitung panjang blok.
- Heks ditulis huruf kecil, tanpa spasi, panjangnya selalu genap.
- Key 16 char: kalau user memasukkan bukan 16 char, **putuskan dan tulis** salah satu:
  (a) tolak, (b) padding dengan spasi/0 ke 16, (c) turunkan dengan cara sederhana.
  Rekomendasi demo: (a) tolak + minta ulang, paling gampang dijelaskan. Alternatif: dukung
  AES-128/192/256 lewat key 16/24/32 char.

## Framing pesan TCP (biar tidak ada pesan menempel/terpotong)

TCP stream tidak punya batas pesan. Semua pesan diikat dengan header 4 byte:

```
[MAGIC 2B][LEN 2B big-endian][PAYLOAD = teks ASCII][\n]
contoh:  KA01|0057|LANGKAH3|TICKET|9c11ab22...
```

- Payload tetap teks ASCII supaya **terbaca manusia** di Wireshark — nilai plus saat demo.
- Hanya field ciphertext yang berupa heks, jadi satu baris stream tetap terlihat rapi.
- Fungsi wajib: `send_msg(sock, text)` dan `recv_msg(sock)` di `src/ksilib/net/framing.py`.

## Skema pesan (isi namanya sesuai PPT kelasmu)

| Pesan | Field (dipisah `|`) | Pengirim |
|-------|---------------------|----------|
| REQUEST | `LANGKAH1|A|B` | Alice → KDC |
| REPLY | `LANGKAH2|<heks terenkripsi K_as>` | KDC → Alice |
| TICKET | `LANGKAH3|<heks terenkripsi K_bs>` | Alice → Bob |
| CHALLENGE | `LANGKAH4|<heks K_ab>` | Bob → Alice |
| RESPONSE | `LANGKAH5|<heks K_ab>` | Alice → Bob |
| DATA | `MSG|<heks K_ab>` | bolak-balik Alice ↔ Bob |
| KONTROL | `KEY?<nama>`, `PING`, `BYE` | interaktif (no.5) |

`KEY?` dipakai buat menunjukkan key boleh berganti tanpa restart; program tidak pernah mengirim
key/session key terbuk di kanal chat (hanya lewat KDC terenkripsi).

## Padding (PKCS#7, blok 16)

```
isi 5 byte  -> tambah 11 byte bernilai 0x0b
isi 16 byte -> tambah 1 blok penuh 0x10
```
Kalau mode CBC: IV 16 byte ASCII/hex dikirim di depan payload (tandanya `IV:`), dan jelaskan IV
bukan rahasia.

## Log & tampilan yang konsisten

```
[11:24:03][ALICE] LANGKAH 3 -> BOB 192.168.1.12:5555
[11:24:03][ALICE]   plaintext : "TICKET|alice" (ASCII)
[11:24:03][ALICE]   key       : "KbsMasterKey0001" (ASCII, dari config, tidak di-hardcode)
[11:24:03][ALICE]   ciphertext: 9c11ab22...  (HEX)
[11:24:03][BOB]     ciphertext diterima 9c11ab22... -> decrypt -> "TICKET|alice"
```

Simpan salinan log ini ke `report/bab-4-hasil/` (mis. `log-alice-2026-11-05.txt`) sebagai bukti.

## Tabel test case dasar (pindahkan hasilnya ke tests/)

| # | Plaintext (ASCII) | Key (ASCII 16) | Ciphertext (HEX) hasil program | Cocok vektor FIPS? |
|---|---|---|---|---|
| 1 | `hello` | `0123456789abcdef` | | |
| 2 | `0123456789abcdef` (16) | `0123456789abcdef` | | ya, lihat `tests/README.md` |
| 3 | `a` | `ABCDEFGHIJKLMNOP` | | |
| 4 | `pesan panjang yang melebihi satu blok untuk uji padding PKCS7` | `KEYDUAABCDEFGHIJKLMNOP` | | |
| 5 | non-ASCII `haloño` | | ditolak, bukan salah encrypt | |
