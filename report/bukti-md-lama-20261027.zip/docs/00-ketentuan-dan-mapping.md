# Ketentuan Tugas -> Pemenuhan di Proyek Ini

Kolom "Status" diisi `BELUM` / `PROSES` / `SELESAI (bukti: ...)`. Ini jadi senjata kalau dosen
menanya "ketentuan no. X mana buktinya?".

| No | Ketentuan (ringkas) | Di mana dipenuhi | Bukti saat demo | Status |
|----|---------------------|------------------|-----------------|--------|
| 2 | Key distribution KDC–Alice–Bob, 3 IP berbeda, skenario sesuai PPT, setelah langkah ke-5 komunikasi AES | `src/ksilib/kdc/`, `src/kdc`, `src/alice`, `src/bob`; alur dicatat di `docs/02-skenario-distribusi-key.md`; topologi `docs/01` | Log 5 langkah + screenshot Wireshark `captures/` | SELESAI - lihat QUICKSTART.md |
| 3 | Komunikasi dua arah, Alice & Bob bisa jadi sender sekaligus receiver | `src/ksilib/net/` (kedua sisi buka socket & listen; arsitektur client-client) | Bolak-balik pesan 2 arah di 2 terminal beda IP | SELESAI - lihat QUICKSTART.md |
| 4 | Key & plaintext ASCII, ciphertext Hex; AES & KDC manual; key bisa diubah, tidak di-hardcode | `src/ksilib/aes/` (manual), `src/ksilib/utils/` (ascii<->hex), key dari `config/hosts/*.env` atau input interaktif | Tunjukkan `grep -R "import Crypto" src` kosong; tunjukkan ciphertext heks | SELESAI - lihat QUICKSTART.md |
| 5 | Program interaktif, key bisa diganti tanpa restart | Menu interaktif di `src/main.py`: `d` skenario, `k` kirim, `r` baca, `g` ganti key, `u` uji AES, `s` status | Ganti key di tengah demo, kirim ulang, tunjukkan ciphertext berubah | SELESAI - lihat QUICKSTART.md |
| 6 | Wireshark siap: interface benar, filter disiapkan, transmisi terlihat | `docs/05-panduan-wireshark.md` + `QUICKSTART.md` bab 3 | pcap di `captures/` | **BELUM - Wireshark belum terpasang di laptop ini** |
| 7 | Program jalan sebelum demo; tiap anggota paham AES, KDC, arsitektur; demo tidak baca plek ketiplek | `docs/03-catatan-aes-manual.md` (masing-masing isi sendiri), `demo/not-poin/` (hanya poin), `docs/07-pembagian-tim.md` | Sesi saling-tanya antaranggota sebelum demo | **PROSES - isi docs/03 + latihan kuis** |
| 11 | Anti-plagiarisme | `references/` diisi sumber yang dibaca; `docs/03` catatan pribadi; komentar kode menyebut referensi konsep, bukan copy kode | Siap jelaskan asal-usul tiap fungsi | **PROSES - isi `references/` + siap jelaskan tiap fungsi** |
| 12 | Fitur tambahan dijelaskan dengan baik -> nilai tambah | `docs/08-fitur-tambahan.md` | Demo fitur + jelaskan kegunaannya | PROSES - sudah ada: TTL session key, sidik key (key confirmation), auto-detect IP, uji known-answer FIPS-197 |

> Catatan: angka 2–7, 11, 12 mengikuti kutipan soal yang kamu kirim. Butir 1, 8, 9, 10 belum ada
> di tanganku — lengkapi tabel ini begitu kamu kirim soal lengkapnya (misal: format laporan,
> tenggat, keanggotaan tim, cara pengumpulan).

## Cara pakai folder `docs/`

- `01`–`04` = spesifikasi teknis. Isi **sebelum** ngoding biar tidak bolak-balik rombak.
- `03` = bukti pemahaman (syarat no.7). Kurasinya: tiap anggota menulis dengan kalimat sendiri,
  lalu saling koreksi. Jangan copy dari slide.
- `05`–`07` = persiapan demo.
