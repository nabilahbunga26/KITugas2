# Skenario Key Distribution (KDC → Alice → Bob → AES)

> **PENTING:** struktur di bawah ini adalah bentuk baku di buku (Needham–Schroeder / Needham–
> Schroeder–Loy) yang *biasanya* dipakai di slide kuliah. **Cocokkan langkah per langkah dengan
> PPT kelas kamu** — dosen menilai "skenario mengikuti PPT yang diterangkan di kelas". Kalau di
> PPT jumlah/tukar pesannya beda, ubah tabel ini dan ikuti yang PPT.

## Notasi

| Simbol | Arti | Onde di kode |
|--------|------|--------------|
| `K_as` | Master key Alice ↔ KDC (ASCII 16) | `config/hosts/kdc.env` `MASTER_KEY_ALICE` |
| `K_bs` | Master key Bob ↔ KDC (ASCII 16) | `config/hosts/kdc.env` `MASTER_KEY_BOB` |
| `K_ab` | Session key AES Alice ↔ Bob, dibangkitkan KDC | hasil langkah 2, disimpan `keystore` |
| `N_a`,`N_b` | Nonce/random challenge | opsional, tergantung PPT |
| `{X}_K` | Ciphertext heks AES dari plaintext ASCII `X` dengan key `K` | `ksilib/aes` |

## Langkah (versi Needham–Schroeder klasik — verifikasi dengan PPT)

| # | Pengirim → Penerima | Pesan | Penjelasan singkat |
|---|---------------------|-------|--------------------|
| 1 | Alice → KDC | `A, B` | Alice minta izin komunikasi dengan Bob |
| 2 | KDC → Alice | `{K_ab, B, {K_ab, A}_K_bs}_K_as` | KDC bangkitkan `K_ab`; bagian dalam = **ticket** yang cuma Bob yang bisa buka |
| 3 | Alice → Bob | `{K_ab, A}_K_bs` | Alice forward ticket ke Bob (Alice tidak bisa baca isinya) |
| 4 | Bob → Alice | `{N_b}_K_ab` | Bob membuktikan ia punya `K_ab` (challenge) |
| 5 | Alice → Bob | `{N_a, N_b}_K_ab` | Alice membuktikan ia pemegang `K_ab` yang sah — **di sini kunci sudah sama di kedua sisi** |
| 6 | Alice ↔ Bob | chat AES dengan `K_ab` | Komunikasi dua arah pakai AES manual (no.2 & no.3) |

Kalau PPT kamu versi lebih sederhana (4 langkah + konfirmasi), biasanya langkah 4–5 diganti
satu pesan konfirmasi saja. **Jangan tambahkan atau kurangi langkah sendiri tanpa bilang di
laporan**, karena demo akan dibandingkan dengan slide.

## Yang wajib terlihat saat demo

Setiap langkah di atas harus memunculkan log di terminal dengan nomor langkah, misalnya:

```
[LANGKAH 1] KIRIM ke KDC(192.168.1.10:4444): ALICE|BOB
[LANGKAH 2] TERIMA dari KDC: 3A7F... (heks)
   -> decrypt K_as -> K_ab = "S3ssionKeyAliceBob" (ASCII), ticket = 9C11...
[LANGKAH 3] KIRIM ke BOB(192.168.1.12:5555): TICKET|9C11...
...
[SIP] K_ab siap. Masuk mode chat AES. ketik /key untuk ganti key, /kirim <teks>, /terima
```

- Log **plaintext ASCII** dan **ciphertext heks** tampil berpasangan (bukti no.4).
- Setelah langkah 5, program masuk mode chat; jangan paksa user restart (no.5).

## Cek kebenaran distribusi (isi setelah jalan)

| Uji | Harapan | Lulus? |
|-----|---------|--------|
| `K_ab` di terminal Alice == `K_ab` di terminal Bob | sama persis | |
| Pesan Alice -> Bob didekripsi Bob dengan `K_ab` | plaintext kembali utuh | |
| Pesan Bob -> Alice didekripsi Alice dengan `K_ab` | plaintext kembali utuh | |
| Ciphertext di kabel (Wireshark) berupa heks, tidak ada plaintext | terlihat di `follow tcp stream` | |
| Key diganti setelah langkah 5 | ciphertext berubah, komunikasi tetap jalan | |

## Ancaman yang bisa dijelaskan (nilai tambah pemahaman)

- Replay: tiket `{K_ab,A}_K_bs` bisa dipakai ulang → alasan perlu nonce/timestamp (langkah 4–5).
- KDC pegang semua master key → single point of compromise.
- Man-in-the-middle di jaringan lab: tunjukkan bahwa tanpa `K_as`/`K_bs`, penyadap tidak bisa
  memperoleh `K_ab` walau tiket terekam di Wireshark.

## Format pesan yang jadi diimplementasikan (lihat `src/ksilib/kdc/protocol.py`)

Pesan = satu baris ASCII, field dipisah `|`, ciphertext selalu heks. Diambil Needham–Schroeder
klasik ditambah dua hal praktis supaya bisa jalan di 3 IP tanpa mengetik alamat manual.

| Langkah | Pesan di kabel | Isi sebelum dienkripsi | Key yang dipakai |
|---------|----------------|------------------------|------------------|
| registrasi | `REG|BOB|5555` → `REGOK|BOB` | - (terbuka, cuma nama & port) | - |
| 1 | `REQ1|ALICE|BOB` | - | - |
| 2 | `REP2|<heks>` | `K=<K_ab>|B=<ip:port>|TICKET=<heks>` | `K_as` |
| 3 | `TICKET3|<heks>` | `K=<K_ab>|NAME=ALICE|A=<ip:port>` | `K_bs` |
| 4 | `CHAL4|<nonce>|<heks>` | `NONCE=<n>` | `K_ab` |
| 5 | `RESP5|<heks>` | `NONCE=<n>|REPLY=<n+1>` | `K_ab` |
| 6 | `MSG|<heks>` | plaintext chat ASCII | `K_ab` |
| kontrol | `KCONF|<sidik4hex>` | cek kedua sisi pakai key sama | - |

Penyimpangan dari buku yang **harus kamu sebut di laporan** (biar tidak dikira salah):

1. Tiket ikut membawa alamat pengaju (`A=<ip:port>`) supaya Bob bisa membalas tanpa konfigurasi IP.
2. KDC menyimpan alamat dari header TCP (`REG`), bukan dari buku alamat terpisah.
3. `REPLY=<nonce+1>` (versi sederhana, bukan `f(Na)`), dan tantangannya satu arah saja di langkah 4-5.
4. `sidik(key)` = checksum 32-bit untuk mencocokkan key, bukan hash kriptografis.

Versi yang dipakai kelas (PPT) tetap jadi acuan: kalau PPT tidak punya langkah 4-5, matikan
challenge-nya dengan menghapus panggilan `_tunggu("CHAL")` — tapi jangan sampai skenarionya
tidak sama dengan slide tanpa kamu bilang.
