# Checklist Demo

## H-3 hari

- [ ] AES lulus known-answer test (`tests/aes/`, vektor FIPS-197).
- [ ] Round-trip `encrypt → decrypt` kembali persis untuk semua test case `docs/04`.
- [ ] Skenario 1–5 jalan di 3 IP nyata (bukan cuma di 1 laptop).
- [ ] Chat dua arah jalan: Alice→Bob dan Bob→Alice, tanpa restart.
- [ ] Ganti key saat program berjalan → ciphertext berubah, komunikasi tetap benar.
- [ ] Tidak ada key di-hardcode: `grep -Rin "key.*=.*[\"']" src/` menghasilkan config/env saja.
- [ ] Laporan Bab 4 ada log + screenshot Wireshark.

## H-1 hari (gladi penuh, pakai alat yang akan dibawa)

- [ ] Ketiga perangkat/VM di network yang sama, `ping` tiga arah berhasil.
- [ ] Firewall sudah mengizinkan port (`scripts/setup/`), atau sudah dites dengan mati sementara.
- [ ] Wireshark terpasang & interface dikenali di perangkat pengamat.
- [ ] Program di-copy ke tiap perangkat memakai `deploy/README.md`, tanpa `pip install` lagi.
- [ ] Semua anggota presentasi 1x penuh (max 15 menit) saling menilai.
- [ ] Backup: folder `.zip` di flashdisk/laptop cadangan + 1 VM snapshot.

## 15 menit sebelum demo

- [ ] Wireshark dibuka, interface dipilih, filter diketik & di Enter (dianggap aktif).
- [ ] 3 terminal siap: KDC, Alice, Bob (history bersih, font cukup besar).
- [ ] `config/hosts/*.env` sudah diisi IP & master key demo (jangan key asal).
- [ ] KDC dijalankan duluan, lalu Alice/Bob — cek tidak ada error port.
- [ ] Bawa catatan test case (tabel `docs/04`) buat diisi hasil live.
- [ ] Matikan notifikasi/noise, layar tidak lock.

## Saat demo — urutan aman

1. Perkenalan arsitektur + topologi 3 IP (tunjuk `docs/diagram/topologi.md`).
2. Jalankan langkah 1–5 KDC, bacakan tiap langkah sambil tunjuk log.
3. Tunjuk Wireshark: apa yang terlihat (heks) dan apa yang tidak (key).
4. Chat dua arah 2–3 pesan bolak-balik.
5. Ganti key interaktif, kirim ulang, bandingkan ciphertext.
6. (Opsional) Fitur tambahan `docs/08` + jelaskan gunanya.
7. Tutup dengan kesimpulan: di mana `K_ab` dihasilkan, bagaimana keduanya menyamakan kunci.

## Yang sering menjatuhkan nilai

- [ ] Menjawab "terserah yang bikin" saat dosen tanya ke anggota tertentu (no.7).
- [ ] Membaca teks/screenplay saat presentasi — yang dipakai adalah `demo/not-poin/`.
- [ ] Pakai `pycryptodome` lalu bilang "manual" (no.4 fatal).
- [ ] Ciphertext belum heks / plaintext dikirim terbuk karena lupa enkripsi di satu arah.
- [ ] Key masih tertulis di dalam `.py`.
- [ ] Interface Wireshark dipilih saat demo sudah jalan (no.6).
- [ ] Skenario tidak sama dengan PPT kelas karena tim pakai versi dari internet tanpa bilang.

## Sisa ketentuan (1, 8, 9, 10)

Butir soal yang belum kamu kirim biasanya soal administrasi — tambahkan ceklisnya di sini begitu
lengkapnya ada: format & batas laporan, cara kumpulkan, daftar anggota & pembagian,
jumlah/durasi demo, batas perangkat, aturan penggunaan AI/referensi.
