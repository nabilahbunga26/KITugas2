# Diagram Urutan (Sequence) Distribusi Key

Ikuti jumlah langkah di PPT kelasmu kalau berbeda dari ini (lihat catatan di
`docs/02-skenario-distribusi-key.md`).

```mermaid
sequenceDiagram
    autonumber
    participant A as Alice (192.168.1.11)
    participant K as KDC (192.168.1.10)
    participant B as Bob (192.168.1.12)
    A->>K: LANGKAH1: A, B
    K->>A: LANGKAH2: {Kab, B, {Kab,A}_Kbs}_Kas   (HEX)
    Note over A: decrypt K_as -> dapat Kab + ticket
    A->>B: LANGKAH3: {Kab,A}_Kbs  (ticket, HEX)
    Note over B: decrypt K_bs -> dapat Kab
    B->>A: LANGKAH4: {Nb}_Kab
    A->>B: LANGKAH5: {Na,Nb}_Kab
    Note over A,B: Kab sama di kedua sisi -> siap AES
    A->>B: LANGKAH6: MSG {plaintext}_Kab
    B->>A: LANGKAH6: MSG {plaintext}_Kab   (dua arah)
```

Ekspor PNG dan taruh di `report/screenshots/` untuk laporan + slide demo.
