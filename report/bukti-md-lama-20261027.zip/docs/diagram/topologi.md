# Diagram Topologi 3 IP

Render: VSCode/Qoder punya preview Mermaid, atau tempel di https://mermaid.live buat ekspor PNG
(lalu taruh PNG-nya di sini sebagai gambar laporan).

```mermaid
flowchart TB
    subgraph DEV1["Perangkat 1 — KDC<br/>IP: 192.168.1.10 : 4444"]
        KDC["KDC<br/>master key: K_as, K_bs<br/>pembangkit session key K_ab"]
    end
    subgraph DEV2["Perangkat 2 — Alice<br/>IP: 192.168.1.11 : 5555"]
        AL["Alice<br/>sender & receiver<br/>AES manual"]
    end
    subgraph DEV3["Perangkat 3 — Bob<br/>IP: 192.168.1.12 : 5555"]
        BO["Bob<br/>sender & receiver<br/>AES manual"]
    end
    AL -- "langkah 1-2 (K_as)" --> KDC
    BO -- "registrasi (K_bs)" --> KDC
    AL -- "langkah 3,5 ticket (K_bs)" --> BO
    BO -- "langkah 4 challenge (K_ab)" --> AL
    AL <-. "langkah 6 chat AES (K_ab)" .-> BO
```

Ganti IP/port sesuai `docs/01-desain-arsitektur.md`, lalu ekspor `topologi.png` ke folder ini.
