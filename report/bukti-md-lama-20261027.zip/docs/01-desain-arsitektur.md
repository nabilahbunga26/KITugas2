# Desain Arsitektur — 3 Perangkat, 3 IP

## Topologi

Tiga host, masing-masing satu proses. Alice & Bob **client-client**: keduanya membuka listener
maupun melakukan koneksi keluar, jadi tidak ada yang cuma jadi receiver (syarat no.3).

```
                 KDC  (IP_KDC:PORT_KDC)
                /                       \
        registrasi + master key     registrasi + master key
              /                           \
      Alice (IP_A:PORT_A)  <--session key-->  Bob (IP_B:PORT_B)
                     pesan AES lewat TCP, keduanya kirim & terima
```

Sumber gambar Mermaid yang bisa di-render: `diagram/topologi.md`.

## Tabel alamat (WAJIB diisi sebelum implementasi)

| Entitas | Peran | IP address | Port KDC | Port chat sendiri | OS / perangkat |
|---------|-------|-----------|----------|-------------------|----------------|
| Alice | Sender & receiver | `172.20.80.1` (`vEthernet (WSL)`) + `192.168.88.1` (`VMware VMnet1`) | connect ke KDC | `5555` | **Windows host** — Wireshark di sini |
| KDC | Pemberi session key | `172.20.93.6` | `4444` | — | **WSL Ubuntu** (Python 3.14.4) |
| Bob | Sender & receiver | `TBD` (perangkat ke-3) | connect ke KDC | `5555` | masih dipilih: VM VMware / HP Termux / laptop teman |

### Hasil probe nyata (2026-10-27, pakai `scripts/probe/`)

| Tes | Hasil |
|-----|-------|
| `ping 172.20.93.6` dari Windows | ❌ Timeout — WSL2 memblokir ICMP, **bukan** berarti jaringan mati |
| `ping 172.20.80.1` dari WSL | ❌ Timeout — sebab sama |
| TCP WSL → Windows `172.20.80.1:4599` | ✅ `HALO-DARI-WSL-Ubuntu` diterima + balasan `OK-TERIMA-DARI-LISTENER` |
| TCP Windows → WSL `172.20.93.6:4598` | ✅ dua arah jalan **tanpa mengubah firewall** |
| 2 distro WSL (Ubuntu & Ubuntu-22.04) | IP **sama** → tidak dihitung sebagai 2 perangkat |
| Docker / modul Hyper-V | tidak ada di laptop ini |
| VMware Workstation | ada (`vmrun` OK), 0 VM aktif, `Win10_21H1_x64.iso` 5.8 GB di Downloads |

Ulangi tes kapan pun: `python scripts/probe/listen.py --port 4599 --seconds 25` di satu perangkat,
`python scripts/probe/send.py --to IP_PERANGKAT_ITU --port 4599 --text HALO` di perangkat lain.
Path WSL ke folder yang sama: `/mnt/c/Users/LENOVO/Documents/Qoder/2026-10-27/0aff9277/tugas-keamanan-informasi`.

Yang perlu dicek di jaringan kampus/lab:

- [ ] Ketiga IP saling reachable **lewat TCP** (`scripts/probe/`), bukan cuma `ping` — ICMP bisa
      diblok sementara socket-nya sendiri lancar.
- [ ] Tidak ada NAT yang memotong koneksi antar VM (VirtualBox: **Bridged/Host-only**; VMware:
      **VMnet1 Host-only**, jangan NAT).
- [ ] Firewall mengizinkan port di tabel di atas (lihat `scripts/README.md`).
- [ ] Interface yang di-sniff Wireshark = interface yang memegang IP tersebut, bukan `Ethernet`/
      `Loopback` yang salah (lihat `docs/05`).

## Pilihan desain yang perlu disepakati tim

| Keputusan | Opsi | Pilihan tim | Alasan |
|-----------|------|-------------|--------|
| Transport | TCP / UDP | TCP | Urutan pesan jelas, gampang diamati di Wireshark, tidak perlu atur fragmentasi sendiri |
| Bentuk pesan di kabel | panjang(2 byte)+isi heks ASCII | lihat `docs/04` | Anti pesan menempel/terpotong |
| Master key KDC↔Alice, KDC↔Bob | ASCII 16 char dari config | config | Tidak di-hardcode (no.4) |
| Session key | Dibangkitkan KDC, ASCII 16 char | KDC | Jadi "hasil" langkah distribusi |
| Mode AES | ECB / CBC | ___ | ECB paling gampang dijelaskan & tidak perlu IV; CBC butuh IV dikirim terbuk. Tulis alasanmu. |
| Padding | PKCS#7 / null | PKCS#7 | Standar, gampang dijelaskan |
| Interaktif | REPL menu | menu | no.5 |

## Batasan yang bikin demo aman

- Jangan pakai library crypto apa pun (no.4). Kalau butuh heks: `bytes.hex()` / `int.to_bytes`
  bukan `cryptography.AES`.
- Semua key lewat `config/hosts/*.env` atau menu interaktif. Ganti key tidak perlu edit kode.
- Sediakan log tiap langkah bernomor (`[LANGKAH 1] A -> KDC: ...`) supaya gampang dicocokkan
  dengan slide/PPT saat demo dan gampang dilihat di Wireshark.
