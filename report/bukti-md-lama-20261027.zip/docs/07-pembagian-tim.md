# Pembagian Tim

Isi nama anggota. Prinsip: setiap orang punya **satu modul yang ia tulis** dan **satu bagian yang
ia jelaskan di demo**, tapi semua orang wajib paham semuanya (no.7).

| Anggota | NIM | Modul yang ditulis | Dijelaskan saat demo | Dipastikan paham luar kepala |
|---------|-----|--------------------|----------------------|------------------------------|
| [nama 1] | | `ksilib/aes/core.py` (SubBytes..AddRoundKey) | Arsitektur + topologi 3 IP | langkah 1–5 KDC |
| [nama 2] | | `ksilib/aes/keyexp.py` + `decrypt` | Key expansion & round | S-Box, Rcon |
| [nama 3] | | `ksilib/kdc/` + `src/kdc/main.py` | Distribusi key (langkah 1–5) | kenapa tiket tak bisa dibaca Alice |
| [nama 4] | | `ksilib/net/` + chat 2 arah + menu interaktif | Chat dua arah + ganti key + Wireshark | framing TCP, filter |

## Definition of Done per modul

- [ ] Ada minimal 1 test di `tests/` yang gagal kalau modul dirusak.
- [ ] Ada komentar singkat "kenapa", bukan "apa" (mis. kenapa round terakhir tanpa MixColumns).
- [ ] Sudah dites di 3 IP nyata, bukan localhost saja.
- [ ] Penanggung jawab bisa menjelaskan tanpa membuka file.

## Version control (disarankan git, biar kontribusi terbukti)

```bash
cd tugas-keamanan-informasi
git init
git add . && git commit -m "scaffold: struktur folder & dokumen"
# lalu satu branch/commit per modul: "aes: key expansion + round trip test"
```

Commit per orang juga jadi bukti anti-plagiarisme (no.11) kalau ditanya.
