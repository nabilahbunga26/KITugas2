# Fitur Tambahan (no.12 — nilai tambah kalau bisa dijelaskan)

Aturan main: **jangan ambil lebih dari 2**, dan yang diambil harus bisa kamu jelaskan kenapa
berguna serta apa trade-off-nya. Fitur yang tidak teruji justru bikin demo panjang & berisiko.

## Kandidat (urut dari paling murah → paling berisiko)

| # | Fitur | Usaha | Nilai edukasi untuk dijelaskan | Kenapa berguna | Status |
|---|-------|-------|-------------------------------|---------------|--------|
| 1 | Mode `PLAINTEKS-TEST` (kirim tanpa enkripsi, khusus perbandingan) | 15 menit | bedanya terlihat langsung di Wireshark | membuktikan no.4 bekerja | |
| 2 | Ganti key interaktif + riwayat key tanpa restart | sudah syarat no.5 | | | done-by-requirement |
| 3 | Timestamp/expire: session key punya masa berlaku, KDC menolak tiket kadaluarsa | kecil | replay attack | alasan perlu timestamp di Needham-Schroeder | |
| 4 | Nonce & verifikasi challenge (langkah 4–5 penuh) | kecil | mutual authentication | membuktikan keduanya benar pegang `K_ab` | |
| 5 | CBC mode + IV | sedang | ECB vs CBC, pola pada gambar/data berulang | menunjukkan kelemahan ECB | |
| 6 | HMAC/ MAC manual (mis. CBC-MAC) atas payload | sedang | confidentiality ≠ integrity | tunjukkan pesan tak bisa diubah tanpa ketahuan | |
| 7 | Log JSON per langkah + tampilan tabel plaintext/hex berdampingan | kecil | audit trail | demo lebih meyakinkan | |
| 8 | Uji kendali mutu: `python -m pytest` lulus semua | kecil | known-answer test FIPS-197 | klaim "AES kami benar" ada buktinya | |
| 9 | Multi-blok + padding visualisasi (blok mana menghasilkan ciphertext mana) | sedang | | bagus buat ditunjuk di layar | |
| 10 | Deteksi & tolak karakter non-ASCII dengan pesan jelas | kecil | | mencegah bug tampilan | |

## Yang aku ambil untuk demo ini

1. _______ (alasan: _______)
2. _______ (alasan: _______)

## Cara menyiapkan penjelasannya (ini yang dinilai)

Untuk tiap fitur yang diambil, jawab 3 hal ini dalam <= 1 menit:

- **Masalah apa** yang diselesaikan (kaitkan dengan skenario KDC/AES kamu).
- **Di mana** kodenya & bagaimana kamu mengujinya (tunjukkan test/hasil nyata).
- **Trade-off**-nya: apa yang jadi lebih mahal/lebih lambat/lebih rumit.

Kalimat yang bikin dosen curiga: "fitur ini ada di GitHub", "saya belum coba tapi fungsinya...".
