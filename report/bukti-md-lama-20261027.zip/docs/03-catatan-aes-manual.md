# Catatan Pemahaman AES Manual (syarat no.7 — diisi masing-masing anggota)

Cara pakai: tiap anggota menyalin blok "Isian" di bawah ke namanya sendiri di
`docs/07-pembagian-tim.md` atau menandai `[nama]` di tiap bagian, lalu **menulis dengan kalimat
sendiri**. File ini bukan naskah demo. Aturan tesnya: bisa menjelaskan tanpa membuka file, dan
bisa menjawab pertanyaan "kenapa", bukan cuma "apa".

## Rangkuman konsep (bacakan, lalu tutup)

AES = blok cipher 128-bit. Satu putaran (round) terdiri 4 transformasi byte:

| Transformasi | Apa yang terjadi | Kenapa ada |
|--------------|------------------|------------|
| **SubBytes** | tiap byte diganti lewat tabel S-Box | substitusi/nonlinearitas (confusion) |
| **ShiftRows** | baris ke-i digeser kiri i posisi | menyebarkan byte antar kolom (diffusion) |
| **MixColumns** | tiap kolom dikali matriks di GF(2^8) | diffusion lintas baris |
| **AddRoundKey** | XOR state dengan round key ke-i | mengikat kunci ke data |

Urutan round: `AddRoundKey(0)` → 9× [`SubBytes`→`ShiftRows`→`MixColumns`→`AddRoundKey`] →
round terakhir **tanpa MixColumns**. AES-128 = 10 round key (11 kunci, termasuk awal).
State disimpan kolom-demi-kolom (column-major) — ini sumber bug paling sering.

**Key expansion**: 4 word awal = key; selanjutnya `w[i] = w[i-4] XOR T(w[i-1])`, dengan `T` =
RotWord + SubWord + Rcon hanya ketika `i % 4 == 0`.

**Dekripsi** = kebalikannya: `InvSubBytes`, `InvShiftRows`, `InvMixColumns`, urutan transformasi
dibalik, round key dipakai dari belakang. `InvMixColumns` pakai matriks 14,11,13,9.

Yang harus bisa dijawab dosen: kenapa round terakhir tanpa MixColumns? Kenapa ShiftRows bukan
MixColumns yang bikin byte berpindah antar baris? Apa isi S-Box (inverse di GF(2^8) + affine)?

## Isian per orang

### [nama anggota 1] — S-Box & SubBytes
- Kenapa tidak pakai rumus matematika saja saat demo (tabel lebih gampang & benar)?
- Cara bikin S-Box kalau ditanya (inverse + transformasi affine + XOR 0x63).
- Bug yang pernah aku temukan di bagian ini: ______

### [nama anggota 2] — Key expansion & AddRoundKey
- Jalan di kepala: dari key ASCII 16 char → 44 word → 11 round key.
- Apa itu Rcon dan kenapa `i % 4 == 0`.
- Kenapa key ASCII harus 16 byte, apa yang terjadi kalau user input 5 char (→ perlakuan padding
  yang kita putuskan, lihat `docs/04`).

### [nama anggota 3] — ShiftRows, MixColumns, aritmetika GF(2^8)
- `xtime` / perkalian dengan 2, 3, 14, 11, 13 dan reduce polynomial 0x11B.
- Tunjukkan satu kolom dihitung manual di kertas/whiteboard.

### [nama anggota 4] — Mode (ECB/CBC), padding, round-trip
- Kalau ECB: kenapa dua blok identik menghasilkan ciphertext identik, dan kenapa itu buruk.
- PKCS#7: isi byte padding = jumlah byte padding; blok penuh kalau sudah pas 16.
- ASCII ↔ heks: `b"ABC".hex()` = `414243`.

### Semua anggota — KDC & arsitektur
- Jelaskan langkah 1–6 di `docs/02` tanpa melihat.
- Kenapa Alice tidak bisa membaca tiket `{K_ab,A}_K_bs` padahal ia yang mengirimnya ke Bob.
- Di paket mana saja `K_ab` berjalan terenkripsi, dan dengan key apa.

## Latihan saling-tanya sebelum demo (30 menit, wajib)

| Penanya | Ditanya | Topik | Lancar? |
|---------|---------|-------|---------|
| | | SubBytes/S-Box | |
| | | Key expansion/Rcon | |
| | | MixColumns/GF(2^8) | |
| | | Padding & mode | |
| | | Dekripsi (urutan inverse) | |
| | | Langkah 1–5 KDC | |
| | | Kenapa tidak di-hardcode & di mana key dibaca | |
| | | Filter Wireshark yang dipakai | |
