# Bob di VM Alpine (IP ketiga yang benar-benar beda)

Topologi final demo (semua di laptop ini, tiga mesin berbeda):

| Peran | Mesin | IP yang didaftarkan ke KDC | Port |
|-------|-------|---------------------------|------|
| KDC | WSL Ubuntu (VM khusus WSL2) | `172.20.93.6` | 4444 |
| Alice | Windows host (PowerShell) | `192.168.59.1` (adapter VMnet8) | 5555 |
| Bob | VMware Workstation VM (Alpine Linux dari ISO, jalan di RAM) | `192.168.59.x` hasil DHCP VMnet8 | 5555 |

Tiga IP berbeda, tiga mesin berbeda. Bob **bukan** cuma beda port.

Kenapa alamatnya harus "diumumkan" (`ADVERTISE_IP` / `--advertise-ip`): VM menjangkau
Windows lewat adapter VMnet8, bukan lewat IP Wi-Fi laptop, jadi Alice sengaja mendaftar ke
KDC dengan alamat yang bisa diroute Bob. Ini juga bahan penjelasan pas demo.

---

## 0. Sekali saja (butuh ADMIN) — buka jalan dari VM ke KDC di WSL

```powershell
# PowerShell "Run as administrator"
cd C:\Users\LENOVO\Documents\Qoder\2026-10-27\0aff9277\tugas-keamanan-informasi
powershell -ExecutionPolicy Bypass -File scripts\vm\iziin-bob.ps1
```

Isinya: portproxy `192.168.59.1:4444 -> 172.20.93.6:4444` + izinkan TCP 4444/5555/8000 masuk.
IP WSL dibaca otomatis karena berubah tiap boot.

## 1. Server file (biarkan terbuka selama VM mengunduh)

```powershell
python scripts\vm\kemas-dan-serve.py
```

Membuat `vm/proyek.zip` (29 KB, isi `src/` + `config/` + `tests/`) dan menampilkannya di
`http://192.168.59.1:8000/proyek.zip`. Tidak perlu admin. Folder `vm/repo/` (paket Alpine)
ikut ter-serve dari port yang sama; isinya dibuat sekali oleh `python scripts\vm\mirror-apk.py`.

## 2. KDC di WSL (terminal biasa)

```powershell
wsl -d Ubuntu
cd /mnt/c/Users/LENOVO/Documents/Qoder/2026-10-27/0aff9277/tugas-keamanan-informasi
python3 -m src.main --role kdc
```

## 3. Alice di Windows (terminal biasa)

```powershell
cd C:\Users\LENOVO\Documents\Qoder\2026-10-27\0aff9277\tugas-keamanan-informasi
python -m src.main --role alice
```

## 4. Nyalakan VM Bob

Double-klik `vm\bob-vm.vmx` (atau `vmrun start vm\bob-vm.vmx`), lalu **Play**.
Alpine boot dari ISO -> login: user `root`, tanpa password.

Di konsol VM, tempel 2 blok ini (Ctrl+V sudah diizinkan di `.vmx`). Blok pertama **sengaja
statis** — DHCP VMware di laptop ini tidak memberi lease, jadi IP ditentukan sendiri:

```sh
ip addr add 192.168.59.10/24 dev eth0; ip link set eth0 up; ip route replace default via 192.168.59.2; printf 'nameserver 192.168.59.2\nnameserver 8.8.8.8\n' > /etc/resolv.conf; ping -c 2 192.168.59.2
```

**DNS-nya wajib `192.168.59.2`** (DNS proxy punya VMware NAT, lihat `C:\ProgramData\VMware\vmnetdhcp.conf`:
`option domain-name-servers 192.168.59.2`). Pakai `8.8.8.8` saja bikin `apk` gagal di jaringan kampus.

```sh
wget -q -O /root/b.sh http://192.168.59.1:8000/mulai-bob-lokal.sh && sh /root/b.sh
```

Blok 1 = Bob dapat IP `192.168.59.10` + gateway NAT (ping ke `192.168.59.1` harus balas).
Blok 2 = ambil skrip dari laptop; skrip itu memasang `python3`, mengunduh proyek, lalu menjalankan
Bob dengan `--kdc 192.168.59.1:4444 --advertise-ip 192.168.59.10`.

**`mulai-bob-lokal.sh` = jalur utama.** Python-nya tidak di-install pakai `apk` dan tidak lewat
internet: 17 paket Alpine (python3 + seluruh `.so` yang dibutuhkannya) sudah kuunduh dengan
`python scripts\vm\mirror-apk.py`, kubongkar dan kugabung jadi satu `vm\alpine-python3.tgz`
(12,6 MB) oleh `python scripts\vm\rakit-python3.py`. VM cuma perlu `wget` + `tar -xzf -C /`.
`musl` sengaja tidak ikut (libc yang sedang dipakai hidup oleh ISO live).
`mulai-bob.sh` yang lama tetap ada sebagai cadangan kalau jaringan kampus sedang mengizinkan.

> Alpine jalan dari ISO di RAM: **VM di-restart = /root hilang**, tinggal tempel ulang 2 blok itu
> (butuh terminal `python scripts/vm/kemas-dan-serve.py` tetap terbuka di laptop).

## 5. Urutan ketik pas demo

| detik | di mana | ketik | hasil yang terlihat |
|-------|---------|-------|---------------------|
| 1 | Bob (VM) | `d` | `menunggu tiket ... di port 5555` |
| 2 | Alice | `d` | langkah 1-2-3-4-5, lalu `[SIAP]` |
| 3 | Alice | `k halo bob ini alice` | Bob cetak `[CHAT] ... (heks 32 byte)` |
| 4 | Bob | `k halo balik alice` | Alice cetak pesan masuk |
| 5 | Alice | `g KunciGantiDemo26` | `KCONF|BEDA` (wajar, Bob belum ganti) |
| 6 | Bob | `g KunciGantiDemo26` | `KCONF|OK`, `auth=True` dua sisi |
| 7 | Alice | `k pesan setelah ganti key` | ciphertext heks baru |
| 8 | keduanya | `s` | `ip_terdaftar=` beda, `session_key` sama |

## Kalau macet

| gejala | penyebab | perbaikan |
|--------|----------|-----------|
| `wget` gagal | server langkah 1 tertutup / firewall | jalankan lagi `iziin-bob.ps1`, cek port 8000 |
| `apk add` gagal | VM tidak punya internet (DNS) | tempel baris `ip addr add ...` saja, lalu ulangi |
| Bob `Connection refused` ke KDC | portproxy hilang (WSL di-restart = IP berubah) | jalankan ulang `iziin-bob.ps1` |
| Alice `d` tapi Bob diam | Alice mendaftar pakai IP yang salah | cek `s` di Alice: `ip_terdaftar=192.168.59.1` |
| Wireshark kosong | interface salah | capture di **VMnet8** dan **vEthernet (WSL)** |

## Habis demo (bersih-bersih)

```powershell
netsh interface portproxy delete v4tov4 listenaddress=192.168.59.1 listenport=4444
netsh advfirewall firewall delete rule name="ksi-port-4444"
netsh advfirewall firewall delete rule name="ksi-port-5555"
netsh advfirewall firewall delete rule name="ksi-port-8000"
```
