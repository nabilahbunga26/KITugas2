# Wireshark — Persiapan & Filter (syarat no.6)

## Sebelum demo (H-1 dan 10 menit sebelum mulai)

1. Pasang Wireshark di **satu perangkat pengamat** (paling enak di laptop Alice, atau di PC
   perantara kalau ketiganya lewat switch/ hotspot yang sama).
2. **Pilih interface yang benar**: interface yang memegang IP perangkat itu, bukan yang lain.
   Ciri benar: ada paket lalu lintas saat kamu `ping IP_PERANGKAT_LAIN`, dan IPv4-nya cocok dengan
   tabel `docs/01-desain-arsitektur.md`.
   - Kabel → `Ethernet`; Wi‑Fi laptop → `Wi-Fi` / `WLAN`; VirtualBox bridged → adapter host aslinya.
   - Jangan sniff `Loopback`/`Adapter untuk lingkaran pemantauan` kalau IP-nya bukan `127.x`.
3. Mulai tangkapan **sebelum** menjalankan program, supaya langkah 1–5 ikut terekam.
4. Siapkan filter di toolbar (jangan diketik saat demo) — lihat tabel di bawah.
5. Simpan file mentah: `File → Save` ke `captures/demo-YYYYMMDD-thl.pcapng`.
6. Tes cepat: kirim 1 pesan, pastikan appears di daftar paket. Kalau kosong = interface salah
   atau trafik lewat `127.0.0.1` (artinya IP di config keliru, itu yang harus dibetulkan).

## Filter siap pakai (ganti IP sesuai tabel `docs/01`)

| Tujuan | Filter |
|--------|--------|
| Semua trafik antar ketiganya | `ip.addr==192.168.1.10 || ip.addr==192.168.1.11 || ip.addr==192.168.1.12` |
| Alice ↔ KDC (distribusi key) | `ip.addr==192.168.1.11 && ip.addr==192.168.1.10 && tcp.port==4444` |
| Alice ↔ Bob (chat AES) | `ip.addr==192.168.1.11 && ip.addr==192.168.1.12 && tcp.port==5555` |
| Hanya payload langkah 1–2 | `(tcp contains "LANGKAH1") || (tcp contains "LANGKAH2")` |
| Hanya ciphertext (heks panjang) | `tcp contains "MSG"` |
| Perkecil ke satu percakapan | `tcp.stream==N` (N dari *Right-click → Follow → TCP Stream*) |
| Buang ruido | `!(arp || dns || llmnr || nbss || mdns)` di awal, tinggal `&&` dengan filter di atas |

## Saat demo: urutan cerita 3 menit

1. Tunjukkan **interface + filter** di layar sebelum ada trafik (bukti persiapan).
2. Jalankan langkah 1–2, tunjukkan paket `LANGKAH1/LANGKAH2` lewat; buka *Follow TCP Stream*:
   yang terlihat **heks ciphertext**, bukan key.
3. Jalankan langkah 3–5, tunjukkan tiket `{K_ab}_K_bs` berpindah ke Bob.
4. Kirim 2 pesan bolak-balik (Alice→Bob, Bob→Alice) dengan **`tcp.stream`** terbuka.
5. **Poin emas**: ganti key dari menu interaktif, kirim pesan lagi, tunjukkan ciphertext berubah
   di Wireshark tanpa restart program (bukti no.5 + no.4).

## Cerita pembanding yang biasanya diminta

| Aspek | Tanpa enkripsi | Dengan AES (program kita) |
|-------|----------------|---------------------------|
| Isi di kabel | plaintext ASCII terbaca | hanya ciphertext heks |
| Bisa direplay | langsung terbaca | butuh `K_ab` yang cuma ada di ujung |
| Known plaintext | terlihat | tetap tak terbaca tanpa key |

Kalau dosen minta "coba buktikan", kirim satu pesan mode `PLAINTEKS-TEST` (fitur tambahan,
lihat `docs/08`) agar terlihat bedanya di Wireshark.

## Kalau macet

| Gejala | Penyebab paling mungkin | Cek |
|--------|------------------------|-----|
| Daftar paket kosong | interface salah / sniff di VM tanpa bridged | ping antar perangkat, lihat IPv4 di *Capture Options* |
| Hanya ARP/DNS | IP target beda subnet | `ipconfig` / `ip a` di tiap perangkat |
| Paket keluar tapi `127.0.0.1` | config menunjuk localhost | buka `config/hosts/*.env` |
| Koneksi ditolak | firewall | `scripts/README.md` (netsh rule) / matikan sementara firewall privat |
| Payload tidak kelihatan | TCP-nya tersegmentasi | *Analyze → Follow TCP Stream*, atau pakai *Right-click → Decode As* |
