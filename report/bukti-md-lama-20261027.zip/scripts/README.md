# Skrip Bantu (perintahnya di sini — jalankan manual saat persiapan)

Python yang terdeteksi di laptop ini: `python` = 3.12.10, `py` = 3.14.5. Pakai satu versi yang
sama di ketiga perangkat (hindari jeda 3.12 vs 3.14 saat demo).

## setup — firewall & konektivitas (Windows, jalankan PowerShell sebagai Admin)

```powershell
# Buka port inbound untuk KDC dan chat (diulang di KETIGA perangkat)
New-NetFirewallRule -DisplayName "KSI-KDC-4444" -Direction Inbound -Protocol TCP -LocalPort 4444 -Action Allow
New-NetFirewallRule -DisplayName "KSI-Chat-5555" -Direction Inbound -Protocol TCP -LocalPort 5555 -Action Allow

# Cek port sudah dipakai/belum
Get-NetTCPConnection -State Listen -LocalPort 4444,5555

# Cek konektivitas tiga arah (dari tiap perangkat)
Test-NetConnection 192.168.1.10 -Port 4444
ping 192.168.1.11 ; ping 192.168.1.12

# Lihat interface + IP yang aktif (cocokkan dengan yang di-sniff Wireshark)
Get-NetIPAddress -AddressFamily IPv4 | Format-Table InterfaceAlias, IPAddress
```

Linux/VM lain: `sudo ufw allow 4444/tcp; sudo ufw allow 5555/tcp`, `ip -br a`.

## run — validasi sebelum demo (di perangkat mana pun)

```bash
cd tugas-keamanan-informasi
python -m pytest tests -q                     # AES + round-trip + framing
grep -RinE "import (Crypto|cryptography)|from (Crypto|cryptography)" src/   # harus kosong
python -c "print(b'S3ssionKeyAliceB'.decode('ascii'), len(b'S3ssionKeyAliceB'))"
```

## run — tiga terminal (atau tiga perangkat, lihat `deploy/README.md`)

```bash
python -m src.kdc.main   --config config/hosts/kdc.env      # 1. KDC
python -m src.bob.main   --config config/hosts/bob.env      # 2. Bob (listener)
python -m src.alice.main --config config/hosts/alice.env    # 3. Alice
```

## capture — ambil pcap tanpa GUI (opsional, buat laporan)

```powershell
# tshark belum terpasang di laptop ini; kalau mau, pakai Wireshark CLI dari instalasi Wireshark
& "C:\Program Files\Wireshark\tshark.exe" -i "Wi-Fi" -f "host 192.168.1.11 and host 192.168.1.12" `
  -w ..\captures\chat-alice-bob.pcapng
```

GUI tetap yang utama saat demo (syarat no.6) — tshark hanya buat cadangan/arsip laporan.

## Simpan jadi skrip `.ps1`/`.sh` kalau tim suka satu klik

Taruh di `scripts/setup/` dan `scripts/run/`, contoh nama:
`allow-ports.ps1`, `check-all.ps1`, `run-kdc.ps1`, `run-alice.sh`.
Jangan taruh key di dalam skrip — biarkan skrip hanya memanggil dengan `--config`.
