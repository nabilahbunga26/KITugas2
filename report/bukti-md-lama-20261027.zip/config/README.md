# `config/` — Key & Alamat (tidak di-hardcode di kode)

Ketentuan no.4 minta key bisa diubah dan jangan di-hardcode. Solusinya: program membaca file di
`config/hosts/`, dan menu interaktif (no.5) bisa menimpanya saat runtime.

## Cara pakai

1. Salin tiap `*.example` tanpa akhiran `.example`:
   ```bash
   cd config/hosts
   cp kdc.env.example kdc.env
   cp alice.env.example alice.env
   cp bob.env.example bob.env
   ```
2. Isi IP/port sesuai `docs/01-desain-arsitektur.md` dan master key ASCII 16 karakter.
3. `.env` yang asli sudah masuk `.gitignore` — jangan di-commit (biar key demo tidak tersebar;
   no.11 juga: bukti key tidak ditulis di sumber).

## Format yang dibaca program (parsing sederhana `Kunci=nilai`)

```
# komentari baris dengan #
HOST_IP=192.168.1.11
KDC_IP=192.168.1.10
KDC_PORT=4444
CHAT_PORT=5555
NAME=ALICE
MASTER_KEY=KasMasterKey0001     # 16 char ASCII -> AES-128
SESSION_KEY_FALLBACK=           # kosong = menunggu KDC (jalur benar)
AES_MODE=ECB                    # ECB atau CBC
PADDING=pkcs7
ASCII_ONLY=true
```

## Yang harus dicek

- [ ] `MASTER_KEY` panjangnya 16 ASCII (AES-128). Kalau mau AES-192/256: 24/32 karakter.
- [ ] Alice & Bob pakai **`MASTER_KEY` berbeda** (`K_as` vs `K_bs`) — KDC tahu keduanya.
- [ ] Tidak ada field `SESSION_KEY` yang terisi di config: session key harus **dari KDC**, bukan
      dari config (kalau tidak, skenario distribusi key no.2 tidak terbukti).
- [ ] Program menolak (bukan diam-diam) key salah panjang / karakter non-ASCII.
