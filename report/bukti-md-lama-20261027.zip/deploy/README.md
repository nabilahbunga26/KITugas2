# Deploy ke 3 Perangkat / VM

Karena demo memakai tiga IP berbeda, tiap perangkat menjalankan satu proses. Cara paling aman:
**satu folder proyek utuh di-copy ke tiga perangkat**, hanya file `.env` yang membedakan.

## Yang di-copy (semua perangkat)

```
src/            (semua, termasuk ksilib)
config/hosts/<nama>.env   (hanya file miliknya yang diisi)
tests/          (buat validasi cepat di perangkat target)
docs/           (referensi saat demo)
```

## Perangkat 1 — KDC

```bash
python -m src.kdc.main --config config/hosts/kdc.env
# atau: python src/kdc/main.py config/hosts/kdc.env
```
Harus jalan **paling dulu** (Alice/Bob connect ke port `KDC_PORT`).

## Perangkat 2 — Alice

```bash
python -m src.alice.main --config config/hosts/alice.env
```

## Perangkat 3 — Bob

```bash
python -m src.bob.main --config config/hosts/bob.env
```

## Catatan VirtualBox / VMware (jangan sampai gagal gara-gara jaringan)

| Setelan | Yang benar | Kenapa |
|---------|-----------|--------|
| Adapter | **Bridged Adapter** (atau Host-only kalau semua VM di segmen yang sama) | NAT membuat VM tidak bisa dihubungi dari VM/perangkat lain |
| IP | Manual 1 segmen, mis. `192.168.1.10/11/12` mask `/24`, atau dari DHCP router yang sama | DHCP bisa berubah pas demo |
| Firewall | Izinkan inbound port `4444`, `5555` (lihat `scripts/README.md`) | Koneksi ditolak = demo macet |
| Time sync | Cukup dekat | kalau pakai TTL/nonce |

## Urutan 5 menit sebelum demo

1. Nyalakan 3 perangkat, samakan segmen IP → `ping` tiga arah.
2. Copy folder, isi `.env` milik masing-masing.
3. Cek cepat AES di tiap perangkat: `python -m pytest tests/aes -q` (tanpa internet, tanpa install).
4. Jalankan KDC → Bob → Alice (Bob listen lebih dulu supaya Alice bisa langsung kirim tiket).
5. Wireshark di perangkat pengamat: interface + filter siap (lihat `docs/05`).

## Kalau koneksi antar perangkat gagal

| Gejala | Cek |
|--------|-----|
| `ConnectionRefusedError` | proses sisi tujuan sudah jalan? port di `.env` cocok? firewall? |
| `TimeoutError` | salah IP / beda subnet / adapter NAT |
| Jalan di 1 laptop tapi gagal antar VM | kamu diam-diam pakai `127.0.0.1`; `HOST_IP`/`KDC_IP` harus IP nyata |
| `PermissionError` bind | port dipakai proses lain — ganti port di `.env` |
| `UnicodeEncodeError` | plaintext non-ASCII; ini seharusnya ditolak dengan pesan jelas (no.4) |
