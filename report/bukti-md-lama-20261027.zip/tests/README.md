# Tests — bukti AES & protokol benar

Pakai `pytest` (install sekali di tiap perangkat sebelum demo: `python -m pip install pytest`;
jangan install saat demo). Alternatif tanpa dependency: `python -m unittest`.

## `tests/aes/` — known-answer test (ini yang bikin klaim "manual tapi benar" dipercaya)

Vektor resmi FIPS-197 Lampiran C (AES-128, ECB, satu blok):

| Key (HEX) | Plaintext (HEX) | Ciphertext (HEX) |
|-----------|-----------------|------------------|
| `000102030405060708090a0b0c0d0e0f` | `00112233445566778899aabbccddeeff` | `69c4e0d86a7b0430d8cdb78070b4c55a` |

Vektor AES-192: key `000102...16171819` (24 byte) → ciphertext `dda97ca4864cdfe06eaf70a0ec0d7191`.
Vektor AES-256: key `000102...1e1f` (32 byte) → ciphertext `8ea2b7ca516745bfeafc49904b496089`.

Uji yang harus ada:

- [ ] Satu blok AES-128 cocok dengan tabel di atas (encrypt **dan** decrypt).
- [ ] Round-trip untuk banyak panjang plaintext (1, 15, 16, 17, 32, 33 byte) → kembali persis.
- [ ] Key expansion: 4 word awal = key, cocok dengan round key pertama.
- [ ] `xtime`/perkalian GF(2^8): `0x57 * 0x83 = 0xc1` (vektor yang sering dipakai).
- [ ] S-Box: `sbox[0x00]=0x63`, `sbox[0x53]=0xed`; inverse S-Box konsisten.
- [ ] Padding PKCS#7: blok penuh menambah 1 blok `0x10`.
- [ ] ECB dua blok identik → ciphertext identik (bisa dipakai menjelaskan kelemahannya).

## `tests/protocol/` — distribusi key & dua arah

- [ ] Alice & Bob berakhir memegang `K_ab` yang sama setelah langkah 5 (boleh pakai 3 socket ke
      port berbeda di satu mesin untuk uji otomatis; saat demo tetap pakai IP berbeda).
- [ ] Bob bisa mendekripsi tiket `{K_ab,A}_K_bs` dengan `K_bs`, dan Alice **tidak** bisa.
- [ ] Challenge 4–5 berhasil (mutual authentication).
- [ ] Framing: 100 pesan pendek berturut-turut tidak ada yang menempel/terpotong.
- [ ] Pesan dari key salah → gagal dengan pesan jelas, bukan crash.
- [ ] Ganti key runtime → ciphertext berikutnya berubah, tanpa restart.

## `tests/data/`

- `vectors_fips197.csv` — isi tabel known-answer di atas supaya test baca data, bukan hardcode.
- `plaintext_ascii.txt` — sampel plaintext ASCII buat uji multi-blok/padding.
- `plaintext_nonascii.txt` — sengaja non-ASCII, untuk uji penolakan.

Konvensi: satu test = satu klaim yang bisa kamu tunjukkan saat demo. Sertakan hasil
`pytest -v` di `report/bab-4-hasil/`.
