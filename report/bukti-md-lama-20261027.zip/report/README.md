# Laporan — Kerangka Isi

Sesuaikan format dengan ketentuan kampus (butir soal yang belum dikirim: margin, font, template).
Bagian di bawah dipetakan ke ketentuan dosen supaya tidak ada yang kelewat.

| Bagian | Isi | Menyambung ke ketentuan |
|--------|-----|------------------------|
| Bab 2 — Landasan teori | Prinsip KDC, master vs session key, Needham–Schroeder, struktur AES (SubBytes/ShiftRows/MixColumns/AddRoundKey), key expansion, ASCII vs heks, PKCS#7 | 2, 4 |
| Bab 3 — Perancangan | Topologi 3 IP + tabel port (`docs/01`), diagram urutan langkah (`docs/diagram/urutan-kdc.md`), format pesan & framing (`docs/04`), rancangan menu interaktif (`docs/05` no.5) | 2, 3, 4, 5 |
| `bab-4-hasil/` | Log 5 langkah dari tiap perangkat, pasangan plaintext↔ciphertext, tabel test case terisi, hasil `pytest -v`, screenshot Wireshark, tabel round-trip | 2, 3, 4, 5, 6 |
| `bab-5-kesimpulan/` | Kenapa distribusi key terbukti berhasil, keterbatasan (ECB, KDC single point of trust, replay), fitur tambahan + trade-off | 12 |
| Lampiran | Sumber yang dibaca (PPT kelas, FIPS-197), catatan `docs/03`, diff/potongan kode kunci | 7, 11 |

## Yang biasanya bikin laporan diturunkan nilainya

- Skenario di laporan beda dengan yang didemokan/dengan PPT kelas.
- Tidak ada bukti "3 IP berbeda" → sertakan `ipconfig`/`ip a` tiap perangkat + tangkapan Wireshark
  yang menampilkan kedua IP di kolom Source/Destination.
- Klaim "AES manual" tanpa menunjukkan fungsi round/key expansion di lampiran.
- Screenshot tanpa keterangan (selalu beri caption: perangkat mana, jam, langkah keberapa).
- Tidak menyebut kontribusi tiap anggota (no.11).

## Naming file bukti

```
bab-4-hasil/log-kdc-20261105-1410.txt
bab-4-hasil/log-alice-20261105-1410.txt
bab-4-hasil/log-bob-20261105-1410.txt
bab-4-hasil/pytest-20261105.txt
screenshots/ws-langkah1-2.png
screenshots/ws-chat-dua-arah.png
screenshots/ip-alice.png
```
