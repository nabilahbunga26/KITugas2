# Referensi yang Dibaca (bukti anti-plagiarisme, no.11)

Taruh file yang kamu benar-benar baca di sini, dan tulis 1–2 baris "apa yang aku ambil dari sini".
Kalau tidak ditulis apa yang diambil, daftar ini tidak ada gunanya saat ditanya.

| File / link | Jenis | Diambil untuk | Dibaca oleh |
|-------------|-------|---------------|-------------|
| `ppt-keamanan-informasi-kdc.pdf` | **PPT kelas (WAJIB — skenario harus mengikuti ini)** | urutan langkah 1–5, notasi | semua |
| `fips-197-aes-standard.pdf` | standar AES | S-Box, struktur round, key expansion, vektor known-answer | nama 1, 2 |
| `catatan-kuliah-2026-mm-dd.md` | catatan kelas | definisi master key, tiket | semua |

Cara ambil berkas standar: cari "FIPS PUB 197" di situs NIST (sumber resmi), dan PPT dari
portal kelas/lms kampus — jangan dari repo tugas tahun lalu orang lain.

## Aturan yang dipakai tim

- Konsep boleh diambil dari mana saja, **kode ditulis sendiri** dan bisa dijelaskan barisnya.
- Kalau ada ide yang diadaptasi dari tutorial, tulis sumbernya di komentar modul + di lampiran.
- Tidak menyalin implementasi AES/KDC milik orang lain — itu langsung bikin nilai 0 (no.11).
