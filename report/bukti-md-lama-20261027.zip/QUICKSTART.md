# QUICKSTART — jalanin sekarang (baca ini dulu)

Kode sudah jalan & sudah terbukti lintas IP (Windows ↔ WSL). Ini sisa langkahnya.

## 1. Tes cepat di 1 laptop dulu (2 menit, jangan lewati)

Cara paling gampang: `python scripts/demo/rehearse.py` — ketiganya dijalankan dan diketikkan
otomatis, lalu log-nya dicetak. (Di gladi ini Alice & Bob sengaja pakai `127.0.0.1` supaya muat
di satu laptop; **bukan** itu yang didemokan — lihat bagian 2.)

Cara manual, buka **3 jendela terminal** di folder proyek:

```powershell
cd C:\Users\LENOVO\Documents\Qoder\2026-10-27\0aff9277\tugas-keamanan-informasi
```

```
Terminal 1 (KDC di WSL)      :  wsl -d Ubuntu
                               cd /mnt/c/Users/LENOVO/Documents/Qoder/2026-10-27/0aff9277/tugas-keamanan-informasi
                               python3 -m src.main --role kdc
Terminal 2 (Bob di Windows)  :  python -m src.main --role bob --port 5556
Terminal 3 (Alice di Windows):  python -m src.main --role alice
```

Di terminal Bob ketik: `d`  (dia menunggu tiket)
Di terminal Alice ketik: `d`  (langsung jalan langkah 1→5, lalu `SIAP`)
Lalu: `k halo dari alice` → di Bob muncul `TERIMA`. Balas dari Bob: `k halo balik` → muncul di Alice.
Ganti key tanpa restart: `g` lalu ketik key ASCII 16 karakter (mis. `KunciBaru1234567`),
pasangan juga `g` dengan key yang sama → pesan berikutnya berubah ciphertext-nya.

## 2. Topologi 3 IP yang dipakai demo (sudah disiapkan barusan)

| Peran | Mesin nyata | IP | Perintah |
|-------|-------------|-----|----------|
| KDC | WSL Ubuntu (VM tersendiri) | `172.20.93.6` | `python3 -m src.main --role kdc` |
| Alice | Windows host | `192.168.59.1` (adapter VMnet8) | `python -m src.main --role alice` |
| Bob | **VMware VM "BOB-ksi"** (Alpine Linux dari ISO, jalan di RAM) | `192.168.59.x` dari DHCP VMnet8 | otomatis lewat `sh /root/b.sh` |

Tiga IP berbeda di tiga mesin berbeda — bukan sekadar beda port. Alice wajib mengumumkan
`192.168.59.1` (bukan IP Wi-Fi) supaya paketnya bisa diroute Bob; itu fungsi `ADVERTISE_IP`.
Langkah lengkap + urutan ketik: [docs/09-bob-di-vm-alpine.md](docs/09-bob-di-vm-alpine.md).

Sudah terpasang otomatis (2026-10-27): portproxy `192.168.59.1:4444 -> 172.20.93.6:4444`
(VM tidak bisa menembus NAT WSL sendiri) + rule firewall TCP 4444/5555/8000,
dibuat oleh `scripts/vm/iziin-bob.ps1`. Diperlukan ulang **hanya kalau IP WSL berubah**
(cek `wsl -d Ubuntu hostname -I`, lalu jalankan skrip itu lagi sebagai admin).

## 3. Wireshark

Installer stable sudah ada di `vm\Wireshark-4.4.19-x64.exe` (90 MB, unduhan resmi wireshark.org).
Klik dua kali → Next terus, pastikan **Npcap** tercentang, dan *jangan* centang
"Restrict Npcap driver to admin only" supaya bisa sniff tanpa admin.

Interface yang dicentang saat capture (semuanya di laptop ini):
- `VMware Network Adapter VMnet8` → Alice ↔ Bob (chat AES, port 5555)
- `vEthernet (WSL (Hyper-V firewall))` → Alice ↔ KDC (port 4444)
- `Ethernet/VMnet8` lagi → Bob → KDC lewat portproxy (kelihatan sebagai `192.168.59.x -> 192.168.59.1:4444`)

Filter siap tempel:
```
tcp.port == 4444
tcp.port == 5555
ip.addr == 192.168.59.1 && tcp.port == 4444
tcp contains "REP2"
tcp contains "MSG|"
```
Mulai capture **sebelum** menjalankan program, simpan ke `captures/demo.pcapng`.
Yang ditunjuk ke dosen: klik kanan paket → *Follow → TCP Stream* → isinya `REP2|aeec...` (heks),
dan tidak ada `K=` / plaintext pesan chat → bukti enkripsi bekerja.

## 4. Perintah validasi (tampilin ini kalau dosen nanya "buktinya?")

```powershell
python -m pytest tests -q                 # 6 lulus: vektor FIPS-197 (AES-128/192/256) + end-to-end
python tests/aes/test_fips197.py          # tampilkan satu-satu "LULUS test_vektor_fips197"
Select-String -Path src\*.py -Pattern "Crypto" -Recurse   # kosong = AES ditulis manual
```

Bukti sudah jalan: `report/bab-4-hasil/log-kdc-wsl-20261027.txt` +
`log-bob-windows-20261027.txt` (session key `KRoou8cciLjtFud1` sama di kedua sisi).

## 5. Tiga hal yang wajib bisa kamu jawab (jangan sampai diam)

1. **Di mana session key dibuat?** Di KDC (`bangkitkan_session_key()` di `protocol.py`), key ASCII
   16 karakter, tidak pernah dikirim terbuka — dibungkus dua lapis: `{K_ab, B, {K_ab, A}_K_bs}_K_as`.
2. **Kenapa Alice tidak bisa baca tiket Bob?** Tiket dienkripsi `K_bs`; Alice cuma meneruskan (langkah 3).
3. **Kenapa round terakhir AES tanpa MixColumns?** Supaya enkripsi & dekripsi saling invers dengan
   kunci yang sama — kalau tetap dicampur, struktur inversnya tidak cocok (FIPS-197 §5.3).

Detail lengkap tiap fungsi ada di [docs/03-catatan-aes-manual.md](docs/03-catatan-aes-manual.md).
